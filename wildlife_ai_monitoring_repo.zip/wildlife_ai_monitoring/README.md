# Antarctic Wildlife AI Monitoring & Research Assistant

Hackathon-ready reference implementation for an Antarctic wildlife monitoring platform.

## Stack
- Python + FastAPI
- PostgreSQL + SQLAlchemy
- YOLO-compatible object detection interface
- CNN-compatible health/disease classification interface
- RNN/LSTM-compatible temporal behaviour analysis interface
- HTML/CSS/JavaScript dashboard + chatbot

## Important
The supplied PDF is a list of data sources, not a structured animal-record database. This project therefore:
1. Stores the supplied source references in PostgreSQL.
2. Provides demo wildlife observations for testing the UI.
3. Keeps ML inference behind adapters so real trained YOLO/CNN/RNN weights can be plugged in later.
4. Does not claim demo predictions are real medical diagnoses.

## Run
1. Install Python 3.11+ and PostgreSQL.
2. Create a database named `wildlife_ai`.
3. Copy `.env.example` to `.env` and set your PostgreSQL credentials.
4. Run `pip install -r backend/requirements.txt`
5. Run `uvicorn backend.main:app --reload`
6. Open `http://127.0.0.1:8000`

## Docker
Run `docker compose up --build`.

## API
- GET `/api/health`
- GET `/api/species`
- GET `/api/observations`
- GET `/api/alerts`
- GET `/api/sources`
- POST `/api/chat`
- POST `/api/analyze/image`
- POST `/api/analyze/sequence`
