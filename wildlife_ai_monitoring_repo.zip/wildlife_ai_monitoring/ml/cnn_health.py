class CNNHealthClassifier:
    """Adapter for a CNN health/disease classifier."""
    def predict(self, image_path: str):
        return {
            "model": "CNN health classifier",
            "status": "demo",
            "classification": "requires_review",
            "confidence": 0.76,
            "note": "Screening result only; requires expert validation."
        }
