class YOLODetector:
    """Adapter for a real YOLO model. Replace demo output with trained inference."""
    def __init__(self, weights_path=None):
        self.weights_path = weights_path

    def predict(self, image_path: str):
        return {
            "model": "YOLO-compatible detector",
            "status": "demo",
            "detections": [
                {"label": "penguin", "confidence": 0.91, "bbox": [0.10, 0.15, 0.42, 0.78]}
            ],
            "note": "Demo inference. Attach trained weights for real deployment."
        }
