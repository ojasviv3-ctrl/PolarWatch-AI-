async function getJSON(url){const r=await fetch(url);return r.json()}

async function load(){
  const [obs,species,alerts]=await Promise.all([
    getJSON('/api/observations'),getJSON('/api/species'),getJSON('/api/alerts')
  ]);
  document.getElementById('animalCount').textContent=obs.reduce((a,x)=>a+x.count,0);
  document.getElementById('speciesCount').textContent=species.length;
  document.getElementById('alertCount').textContent=alerts.length;

  let html='<div class="row head"><div>SPECIES</div><div>STATION</div><div>COUNT</div><div>STATUS</div></div>';
  for(const x of obs){
    html+=`<div class="row"><div>${x.species}</div><div>${x.station}</div><div>${x.count}</div><div class="${x.health_status==='normal'?'ok':'warn'}">${x.health_status}</div></div>`;
  }
  document.getElementById('observations').innerHTML=html;
}

function addMessage(text, cls){
  const el=document.createElement('div');
  el.className=cls;
  el.textContent=text;
  document.getElementById('messages').appendChild(el);
  document.getElementById('messages').scrollTop=999999;
}

async function send(){
  const input=document.getElementById('question');
  const q=input.value.trim();
  if(!q)return;
  addMessage(q,'user');
  input.value='';
  try{
    const r=await fetch('/api/chat',{
      method:'POST',
      headers:{'Content-Type':'application/json'},
      body:JSON.stringify({message:q})
    });
    const data=await r.json();
    let answer=data.answer;
    if(data.records && data.records.length) answer += '\\n\\n'+JSON.stringify(data.records,null,2);
    addMessage(answer,'bot');
  }catch(e){
    addMessage('Backend connection error. Start the FastAPI server first.','bot');
  }
}
function ask(q){document.getElementById('question').value=q;send()}
load();
