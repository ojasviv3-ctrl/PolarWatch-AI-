CREATE TABLE IF NOT EXISTS species (
    id SERIAL PRIMARY KEY,
    common_name VARCHAR(120) NOT NULL,
    scientific_name VARCHAR(180),
    conservation_status VARCHAR(80)
);

CREATE TABLE IF NOT EXISTS data_sources (
    id SERIAL PRIMARY KEY,
    name VARCHAR(200) NOT NULL,
    url TEXT,
    description TEXT
);

CREATE TABLE IF NOT EXISTS observations (
    id SERIAL PRIMARY KEY,
    species_id INTEGER REFERENCES species(id),
    station VARCHAR(120) NOT NULL,
    observed_at TIMESTAMP NOT NULL,
    count INTEGER DEFAULT 1,
    latitude DOUBLE PRECISION,
    longitude DOUBLE PRECISION,
    behaviour VARCHAR(120),
    health_status VARCHAR(80),
    disease_risk VARCHAR(80),
    confidence DOUBLE PRECISION,
    source_id INTEGER REFERENCES data_sources(id)
);
