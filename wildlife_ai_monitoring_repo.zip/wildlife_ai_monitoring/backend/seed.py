from datetime import datetime, timedelta
from .database import Base, engine, SessionLocal
from .models import Species, DataSource, Observation

def seed():
    Base.metadata.create_all(bind=engine)
    db = SessionLocal()
    try:
        if db.query(Species).count() == 0:
            db.add_all([
                Species(common_name="Adélie penguin", scientific_name="Pygoscelis adeliae", conservation_status="Least Concern"),
                Species(common_name="Emperor penguin", scientific_name="Aptenodytes forsteri", conservation_status="Near Threatened"),
                Species(common_name="Gentoo penguin", scientific_name="Pygoscelis papua", conservation_status="Least Concern"),
                Species(common_name="Chinstrap penguin", scientific_name="Pygoscelis antarcticus", conservation_status="Least Concern"),
            ])
            db.commit()

        if db.query(DataSource).count() == 0:
            db.add_all([
                DataSource(name="National Centre for Polar and Ocean Research – Bharati", url="https://ncpor.res.in/antarcticas/display/377-bharati", description="Antarctic station reference"),
                DataSource(name="NASA Antarctic Stations", url="https://www.nasa.gov/antarctic-stations-nsf/", description="Antarctic station reference"),
                DataSource(name="Oceanites", url="https://www.oceanites.org", description="Antarctic environmental/wildlife reference"),
                DataSource(name="WHO Avian Influenza A(H5N1)", url="https://www.who.int/teams/global-influenza-programme/avian-influenza/avian-a-h5n1-virus", description="H5N1 reference"),
                DataSource(name="OBIS Antarctic Penguin Biogeography", url="https://obis.org/dataset/b4be83a5-101d-4a82-80dd-b8a39c8026f2", description="Penguin abundance/distribution dataset"),
                DataSource(name="Australian Antarctic Data Centre", url="https://data.aad.gov.au", description="Antarctic data reference"),
                DataSource(name="Penguin Watch", url="https://www.robots.ox.ac.uk/~vgg/data/penguins", description="Time-lapse imagery/classification reference"),
                DataSource(name="Dryad Penguin Watch dataset", url="https://datadryad.org/dataset/doi%3A10.5061/dryad.vv36g", description="Penguin Watch data reference"),
                DataSource(name="SCAR Antarctic Tracking", url="https://www.obis.org/dataset/48cb8624-a221-47ed-9a6d-b99b0bb394e0", description="Retrospective Antarctic tracking data"),
            ])
            db.commit()

        if db.query(Observation).count() == 0:
            species = {s.common_name: s.id for s in db.query(Species).all()}
            now = datetime.utcnow()
            db.add_all([
                Observation(species_id=species["Adélie penguin"], station="Bharati", observed_at=now-timedelta(hours=5), count=34, behaviour="foraging", health_status="normal", disease_risk="low", confidence=.94, source_id=5),
                Observation(species_id=species["Emperor penguin"], station="Bharati", observed_at=now-timedelta(hours=4), count=12, behaviour="resting", health_status="normal", disease_risk="low", confidence=.91, source_id=7),
                Observation(species_id=species["Gentoo penguin"], station="Maitri", observed_at=now-timedelta(hours=3), count=19, behaviour="movement", health_status="requires_review", disease_risk="moderate", confidence=.78, source_id=7),
                Observation(species_id=species["Chinstrap penguin"], station="Maitri", observed_at=now-timedelta(hours=2), count=27, behaviour="foraging", health_status="normal", disease_risk="low", confidence=.89, source_id=5),
            ])
            db.commit()
    finally:
        db.close()

if __name__ == "__main__":
    seed()
