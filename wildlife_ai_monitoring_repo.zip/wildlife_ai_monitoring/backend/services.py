from sqlalchemy import func
from .models import Species, Observation, DataSource

def chatbot_query(db, message: str):
    text = message.lower().strip()

    if any(x in text for x in ["species", "animals", "wildlife"]):
        rows = db.query(
            Species.common_name,
            Species.scientific_name,
            func.sum(Observation.count).label("total")
        ).join(Observation, Observation.species_id == Species.id).group_by(
            Species.id
        ).all()
        records = [
            {"species": r[0], "scientific_name": r[1], "observations": int(r[2] or 0)}
            for r in rows
        ]
        return "Here are the species currently represented in the monitoring database.", records

    if "bharati" in text or "maitri" in text or "station" in text:
        rows = db.query(
            Observation.station,
            func.sum(Observation.count).label("total")
        ).group_by(Observation.station).all()
        records = [{"station": r[0], "animals": int(r[1] or 0)} for r in rows]
        return "Current observation counts grouped by Antarctic research station:", records

    if any(x in text for x in ["health", "disease", "abnormal", "risk"]):
        rows = db.query(Observation).filter(
            Observation.health_status != "normal"
        ).all()
        records = [{
            "id": r.id,
            "station": r.station,
            "health_status": r.health_status,
            "disease_risk": r.disease_risk,
            "confidence": r.confidence
        } for r in rows]
        return "These records are flagged for review. They are screening indicators, not diagnoses.", records

    if any(x in text for x in ["behaviour", "behavior", "activity"]):
        rows = db.query(
            Observation.behaviour,
            func.sum(Observation.count).label("total")
        ).group_by(Observation.behaviour).all()
        records = [{"behaviour": r[0], "observations": int(r[1] or 0)} for r in rows]
        return "Observed behaviour/activity categories:", records

    if "source" in text or "database" in text:
        rows = db.query(DataSource).all()
        records = [{"name": r.name, "url": r.url, "description": r.description} for r in rows]
        return "The platform currently references the supplied Antarctic wildlife data sources.", records

    total = db.query(func.sum(Observation.count)).scalar() or 0
    return (
        f"I can query the wildlife monitoring database. There are {int(total)} "
        "recorded animals in the current demo dataset. Try asking about species, "
        "stations, health/disease risk, behaviour, or sources."
    ), []
