from pathlib import Path
import tempfile
from fastapi import FastAPI, Depends, UploadFile, File
from fastapi.middleware.cors import CORSMiddleware
from fastapi.staticfiles import StaticFiles
from sqlalchemy.orm import Session

from .database import get_db
from .models import Species, Observation, DataSource
from .services import chatbot_query
from .seed import seed
from ml.yolo_detector import YOLODetector
from ml.cnn_health import CNNHealthClassifier
from ml.rnn_behavior import RNNBehaviorAnalyzer

app = FastAPI(title="Antarctic Wildlife AI Monitoring API", version="1.0.0")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

try:
    seed()
except Exception as exc:
    print("Database initialization skipped:", exc)

yolo = YOLODetector()
cnn = CNNHealthClassifier()
rnn = RNNBehaviorAnalyzer()

@app.get("/api/health")
def health():
    return {"status": "online", "service": "Antarctic Wildlife AI Monitoring"}

@app.get("/api/species")
def species(db: Session = Depends(get_db)):
    return [{"id": s.id, "common_name": s.common_name,
             "scientific_name": s.scientific_name,
             "conservation_status": s.conservation_status}
            for s in db.query(Species).all()]

@app.get("/api/observations")
def observations(db: Session = Depends(get_db)):
    rows = db.query(Observation, Species).join(
        Species, Observation.species_id == Species.id
    ).order_by(Observation.observed_at.desc()).all()
    return [{"id": o.id, "species": s.common_name, "station": o.station,
             "observed_at": o.observed_at, "count": o.count,
             "behaviour": o.behaviour, "health_status": o.health_status,
             "disease_risk": o.disease_risk, "confidence": o.confidence}
            for o, s in rows]

@app.get("/api/alerts")
def alerts(db: Session = Depends(get_db)):
    rows = db.query(Observation, Species).join(
        Species, Observation.species_id == Species.id
    ).filter(Observation.health_status != "normal").all()
    return [{"id": o.id, "species": s.common_name, "station": o.station,
             "health_status": o.health_status, "disease_risk": o.disease_risk,
             "confidence": o.confidence} for o, s in rows]

@app.get("/api/sources")
def sources(db: Session = Depends(get_db)):
    return [{"id": s.id, "name": s.name, "url": s.url,
             "description": s.description} for s in db.query(DataSource).all()]

@app.post("/api/chat")
def chat(request: dict, db: Session = Depends(get_db)):
    answer, records = chatbot_query(db, request.get("message", ""))
    return {"answer": answer, "records": records}

@app.post("/api/analyze/image")
async def analyze_image(file: UploadFile = File(...)):
    suffix = Path(file.filename or ".jpg").suffix
    with tempfile.NamedTemporaryFile(delete=False, suffix=suffix) as temp:
        temp.write(await file.read())
        path = temp.name
    return {"detection": yolo.predict(path), "health_screening": cnn.predict(path)}

@app.post("/api/analyze/sequence")
def analyze_sequence(sequence: list):
    return rnn.predict(sequence)

app.mount("/", StaticFiles(directory="frontend", html=True), name="frontend")
