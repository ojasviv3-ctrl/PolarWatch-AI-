from sqlalchemy import Column, Integer, String, Float, DateTime, ForeignKey, Text
from .database import Base

class Species(Base):
    __tablename__ = "species"
    id = Column(Integer, primary_key=True)
    common_name = Column(String(120), nullable=False)
    scientific_name = Column(String(180))
    conservation_status = Column(String(80))

class DataSource(Base):
    __tablename__ = "data_sources"
    id = Column(Integer, primary_key=True)
    name = Column(String(200), nullable=False)
    url = Column(Text)
    description = Column(Text)

class Observation(Base):
    __tablename__ = "observations"
    id = Column(Integer, primary_key=True)
    species_id = Column(Integer, ForeignKey("species.id"))
    station = Column(String(120), nullable=False)
    observed_at = Column(DateTime, nullable=False)
    count = Column(Integer, default=1)
    latitude = Column(Float)
    longitude = Column(Float)
    behaviour = Column(String(120))
    health_status = Column(String(80))
    disease_risk = Column(String(80))
    confidence = Column(Float)
    source_id = Column(Integer, ForeignKey("data_sources.id"))
